"""Ariadne modification: calibrated multiscale candidate proposals."""
from __future__ import annotations

from scitbx.array_family import flex

from ariadne.spots import propose


class AriadneThresholdExt:
    """Experimental count-excess proposals; downstream indexing verifies Bragg evidence."""
    name = "ariadne"

    @staticmethod
    def phil():
        from libtbx.phil import parse
        return parse("""
gain_adu_per_photon = None
    .type = float(value_min=0.000001)
offset_adu = 0
    .type = float
readout_variance_adu = 0
    .type = float(value_min=0)
noise_model = *poisson poisson_gaussian
    .type = choice
background_width = 31
    .type = int(value_min=3)
exclusion_width = 7
    .type = int(value_min=1)
scales = 1 3 5
    .type = ints
score_threshold = 6
    .type = float(value_min=0.1)
support_sigma = 1
    .type = float(value_min=0)
min_valid_fraction = 0.5
    .type = float(value_min=0.01, value_max=1)
background_iterations = 2
    .type = int(value_min=0, value_max=5)
""")

    def __init__(self, params):
        self.params = params.spotfinder.threshold.ariadne

    def compute_threshold(self, image, mask, **kwargs):
        p = self.params
        selected = propose(image.as_numpy_array(), mask.as_numpy_array(),
                           gain=p.gain_adu_per_photon, offset=p.offset_adu,
                           readout_variance=p.readout_variance_adu, noise_model=p.noise_model,
                           background_width=p.background_width, exclusion_width=p.exclusion_width,
                           scales=p.scales, score_threshold=p.score_threshold,
                           support_sigma=p.support_sigma, min_valid_fraction=p.min_valid_fraction,
                           background_iterations=p.background_iterations)
        return flex.bool(selected)
